
package com.usecase.service;

import java.util.List;

import com.usecase.model.PatientInfo;

public interface PatientInfoService {

	long save(PatientInfo book);

	PatientInfo get(long id);

	List<PatientInfo> list();

	void update(long id, PatientInfo member);

	void delete(long id);
}