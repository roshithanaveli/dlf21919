package com.usecase.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.usecase.dao.PatientInfoDao;
import com.usecase.model.PatientInfo;


@Service
@Transactional(readOnly = true)
public class PatientInfoImp implements PatientInfoService {

   @Autowired
   private PatientInfoDao memberDao;

   @Transactional
   @Override
   public long save(PatientInfo member) {
      return memberDao.save(member);
   }


@Override
public PatientInfo get(long id) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public List<PatientInfo> list() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public void update(long id, PatientInfo member) {
	// TODO Auto-generated method stub
	
}

@Override
public void delete(long id) {
	// TODO Auto-generated method stub
	
}

  
}