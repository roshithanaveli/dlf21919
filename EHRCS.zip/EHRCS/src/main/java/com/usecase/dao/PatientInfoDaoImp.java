package com.usecase.dao;


import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.usecase.model.PatientInfo;


@Repository
public class PatientInfoDaoImp implements PatientInfoDao {

	@Autowired
	   private SessionFactory sessionFactory;

	@Override
	public long save(PatientInfo patientinfo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public PatientInfo get(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PatientInfo> list() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(long id, PatientInfo patientinfo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(long id) {
		// TODO Auto-generated method stub
		
	}

	 

}

