package com.usecase.dao;


import java.util.List;

import com.usecase.model.PatientInfo;


public interface PatientInfoDao {

   long save(PatientInfo patientinfo);
   

   PatientInfo get(long id);

   List<PatientInfo> list();

   void update(long id, PatientInfo patientinfo);

   void delete(long id);

}